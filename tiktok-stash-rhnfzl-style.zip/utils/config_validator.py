from __future__ import annotations

from .env_config import load_settings


def validate_configuration() -> dict:
    cfg = load_settings()
    warnings = []

    if not cfg.get("Settings", "save_directory", fallback="").strip():
        warnings.append("save_directory is empty")

    if cfg.get("Storage", "provider", fallback="local").lower() not in {"local", "mega"}:
        warnings.append("Storage provider should be local or mega")

    if cfg.get("Settings", "check_type", fallback="LOG").upper() not in {"LOG", "DIR"}:
        warnings.append("check_type should be LOG or DIR")

    return {"warnings": warnings}
