from __future__ import annotations

DEFAULT_SAVE_DIRECTORY = "tiktok/"
DEFAULT_CHECK_TYPE = "LOG"
DEFAULT_SOURCE_DIRECTORY = "input/"
DEFAULT_SOURCE_FILE = None
DEFAULT_PROCESS_API = True
DEFAULT_PROCESS_EXPORT = False

LOG_FILE_NAME = "file_log.json"
INDEX_DB_NAME = "archive.db"
RETRY_DB_NAME = "retry_queue.sqlite3"
