from __future__ import annotations

import configparser
import os
from pathlib import Path
from typing import Any

INVALID_VALUES = {"", "None", None}


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def load_settings() -> configparser.ConfigParser:
    parser = configparser.ConfigParser()
    parser.read(_repo_root() / "settings.ini")
    return parser


def _resolve(value: Any, env_name: str) -> Any:
    if value in INVALID_VALUES:
        return os.getenv(env_name)
    return value


def load_config_and_env():
    cfg = load_settings()

    client_id = _resolve(cfg.get("Configuration", "client_id", fallback=None), "TIKTOK_CLIENT_ID")
    client_secret = _resolve(cfg.get("Configuration", "client_secret", fallback=None), "TIKTOK_CLIENT_SECRET")
    username = _resolve(cfg.get("Configuration", "username", fallback=None), "TIKTOK_USERNAME")
    password = _resolve(cfg.get("Configuration", "password", fallback=None), "TIKTOK_PASSWORD")

    return client_id, client_secret, username, password


def get_config():
    return load_settings()
