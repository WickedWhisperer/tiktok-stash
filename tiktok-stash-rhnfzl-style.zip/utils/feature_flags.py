from __future__ import annotations

from .env_config import load_settings


def get_feature_summary() -> str:
    cfg = load_settings()
    return (
        "Features: "
        f"process_api={cfg.getboolean('Settings', 'process_api', fallback=True)}, "
        f"process_export={cfg.getboolean('Settings', 'process_export', fallback=False)}, "
        f"download_enabled={cfg.getboolean('Media', 'download_enabled', fallback=True)}, "
        f"storage_provider={cfg.get('Storage', 'provider', fallback='local')}, "
        f"recovery_enabled={cfg.getboolean('Recovery', 'enabled', fallback=True)}"
    )
