from __future__ import annotations

from pathlib import Path
from typing import Iterable

from .env_config import load_settings
from .file_path_validate import validate_and_set_directory
from .log_utils import is_file_logged
from .praw_helpers import load_items_from_path
from .save_utils import save_item_markdown, save_item_json, download_media
from .retry_queue import enqueue_retry


def _source_paths() -> list[Path]:
    cfg = load_settings()
    paths = []

    source_file = cfg.get("Settings", "source_file", fallback="None")
    if source_file and source_file != "None":
        paths.append(Path(source_file))

    export_file = cfg.get("Export", "input_file", fallback="None")
    if export_file and export_file != "None":
        paths.append(Path(export_file))

    source_dir = cfg.get("Settings", "source_directory", fallback="input/")
    if source_dir and source_dir != "None":
        paths.append(Path(source_dir))

    return paths


def collect_items() -> Iterable[dict]:
    for path in _source_paths():
        if path.exists():
            for item in load_items_from_path(path):
                yield item


def save_user_activity(
    save_directory: str | Path,
    log_data: dict,
    check_type: str = "LOG",
    save_as_json: bool = False,
    download_media_enabled: bool = True,
):
    save_directory = validate_and_set_directory(save_directory)
    total_processed = 0
    total_skipped = 0
    total_size = 0

    for item in collect_items():
        unique_key = str(item.get("unique_key") or item.get("id") or item.get("video_id") or item.get("permalink") or "")
        try:
            if not unique_key:
                raise ValueError("Missing unique key")
            if check_type == "LOG" and is_file_logged(log_data, unique_key):
                total_skipped += 1
                continue

            if save_as_json:
                saved_path, byte_count, normalized = save_item_json(item, save_directory)
            else:
                saved_path, byte_count, normalized = save_item_markdown(item, save_directory)

            if download_media_enabled and normalized.get("media_urls"):
                media_dir = Path(save_directory) / "media" / normalized["source"]
                for idx, url in enumerate(normalized["media_urls"], start=1):
                    try:
                        download_media(url, media_dir, f"{normalized['unique_key']}_{idx}")
                    except Exception:
                        pass

            log_data[unique_key] = {
                "file_path": str(saved_path.relative_to(save_directory)),
                "created_at": normalized.get("created_at"),
                "source": normalized.get("source"),
                "type": normalized.get("type"),
            }
            total_processed += 1
            total_size += byte_count

        except Exception as exc:
            enqueue_retry(save_directory, unique_key or "unknown", item, str(exc))
            total_skipped += 1

    return total_processed, total_skipped, total_size


def save_gdpr_export(save_directory: str | Path, log_data: dict):
    return save_user_activity(save_directory, log_data, check_type="DIR", save_as_json=True, download_media_enabled=False)
