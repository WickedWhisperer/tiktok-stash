from __future__ import annotations

from pathlib import Path

from .url_security import safe_filename


def validate_and_set_directory(save_directory: str) -> Path:
    path = Path(save_directory).expanduser().resolve()
    path.mkdir(parents=True, exist_ok=True)
    return path


def ensure_parent(path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def sanitize_path_segment(value: str, fallback: str = "item") -> str:
    return safe_filename(value, fallback=fallback)
