from __future__ import annotations

import json
from pathlib import Path
from threading import Lock

from .constants import LOG_FILE_NAME

_LOG_LOCK = Lock()


def get_log_file_path(save_directory: str | Path) -> Path:
    return Path(save_directory) / LOG_FILE_NAME


def load_file_log(save_directory: str | Path) -> dict:
    path = get_log_file_path(save_directory)
    if path.exists():
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_file_log(log_data: dict, save_directory: str | Path) -> None:
    path = get_log_file_path(save_directory)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(log_data, f, indent=2, ensure_ascii=False)
    tmp.replace(path)


def is_file_logged(log_data: dict, unique_key: str) -> bool:
    return unique_key in log_data


def log_file(log_data: dict, unique_key: str, file_info: dict, save_directory: str | Path) -> None:
    with _LOG_LOCK:
        log_data[unique_key] = file_info


def convert_to_absolute_path(relative_path: str, save_directory: str | Path) -> Path:
    return Path(save_directory) / relative_path
