from __future__ import annotations

import json
from pathlib import Path

from .env_config import load_settings


def build_client():
    """
    Compatibility hook that preserves the original architecture shape.
    For TikTok Stash, this returns source settings instead of a PRAW client.
    """
    cfg = load_settings()
    return {
        "source_directory": cfg.get("Settings", "source_directory", fallback="input/"),
        "source_file": cfg.get("Settings", "source_file", fallback="None"),
        "export_file": cfg.get("Export", "input_file", fallback="None"),
    }


def load_items_from_path(path: str | Path) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []

    if p.is_file():
        if p.suffix.lower() == ".json":
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data
            if isinstance(data, dict):
                for key in ("items", "data", "videos", "results"):
                    value = data.get(key)
                    if isinstance(value, list):
                        return value
            return []
        if p.suffix.lower() in {".ndjson", ".jsonl"}:
            items = []
            for line in p.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line:
                    items.append(json.loads(line))
            return items
        return []

    items = []
    for child in sorted(p.iterdir()):
        if child.suffix.lower() in {".json", ".ndjson", ".jsonl"}:
            items.extend(load_items_from_path(child))
    return items
