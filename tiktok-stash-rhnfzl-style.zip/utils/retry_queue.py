from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .env_config import load_settings
from .sqlite_manager import ensure_retry_db


def _db_path(save_directory: str | Path) -> Path:
    cfg = load_settings()
    filename = cfg.get("Retry", "dead_letter_file", fallback="retry_dead_letter.sqlite3")
    return Path(save_directory) / filename


def enqueue_retry(save_directory: str | Path, unique_key: str, payload: dict, error: str) -> None:
    cfg = load_settings()
    base_delay = cfg.getint("Retry", "base_retry_delay_seconds", fallback=10)

    conn = ensure_retry_db(_db_path(save_directory))
    try:
        conn.execute(
            """
            INSERT INTO retry_queue (unique_key, payload, attempts, last_error, next_attempt_at, status)
            VALUES (?, ?, 1, ?, ?, 'queued')
            """,
            (
                unique_key,
                json.dumps(payload, ensure_ascii=False),
                error,
                (datetime.now(timezone.utc) + timedelta(seconds=base_delay)).isoformat(),
            ),
        )
        conn.commit()
    finally:
        conn.close()


def fetch_due_retries(save_directory: str | Path, limit: int = 100) -> list[dict]:
    conn = ensure_retry_db(_db_path(save_directory))
    try:
        rows = conn.execute(
            """
            SELECT id, unique_key, payload, attempts, last_error, next_attempt_at
            FROM retry_queue
            WHERE status = 'queued'
            ORDER BY id ASC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [
            {
                "id": row[0],
                "unique_key": row[1],
                "payload": json.loads(row[2]),
                "attempts": row[3],
                "last_error": row[4],
                "next_attempt_at": row[5],
            }
            for row in rows
        ]
    finally:
        conn.close()


def mark_retry_done(save_directory: str | Path, row_id: int) -> None:
    conn = ensure_retry_db(_db_path(save_directory))
    try:
        conn.execute("UPDATE retry_queue SET status='done' WHERE id=?", (row_id,))
        conn.commit()
    finally:
        conn.close()
