from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import requests

from .file_path_validate import sanitize_path_segment
from .time_utilities import utc_now_iso
from .url_security import is_safe_url


def normalize_item(item: dict[str, Any]) -> dict[str, Any]:
    unique_key = str(item.get("unique_key") or item.get("id") or item.get("video_id") or item.get("permalink") or "")
    if not unique_key:
        raise ValueError("item is missing a unique identifier")

    title = str(item.get("title") or item.get("caption") or unique_key)
    source = str(item.get("source") or "unknown")
    item_type = str(item.get("type") or item.get("item_type") or "video")
    created_at = str(item.get("created_at") or item.get("createdAt") or utc_now_iso())

    media_urls = item.get("media_urls") or item.get("media") or []
    if isinstance(media_urls, str):
        media_urls = [media_urls]

    hashtags = item.get("hashtags") or []
    if isinstance(hashtags, str):
        hashtags = [hashtags]

    return {
        "unique_key": unique_key,
        "title": title,
        "source": source,
        "type": item_type,
        "created_at": created_at,
        "caption": str(item.get("caption") or item.get("text") or ""),
        "permalink": str(item.get("permalink") or item.get("url") or ""),
        "author": str(item.get("author") or item.get("username") or ""),
        "hashtags": hashtags,
        "media_urls": [u for u in media_urls if isinstance(u, str)],
        "raw": item,
    }


def render_markdown(item: dict[str, Any]) -> str:
    tags = " ".join(f"#{h.lstrip('#')}" for h in item.get("hashtags", []))
    meta = [
        f"# {item['title']}",
        "",
        f"- Unique Key: `{item['unique_key']}`",
        f"- Source: {item.get('source', '')}",
        f"- Type: {item.get('type', '')}",
        f"- Author: {item.get('author', '')}",
        f"- Created At: {item.get('created_at', '')}",
        f"- Link: {item.get('permalink', '')}",
    ]
    if tags:
        meta.append(f"- Tags: {tags}")
    meta.extend(["", item.get("caption", ""), "", "## Raw JSON", "```json", json.dumps(item["raw"], indent=2, ensure_ascii=False), "```", ""])
    return "\n".join(meta)


def save_item_markdown(item: dict[str, Any], save_directory: str | Path):
    normalized = normalize_item(item)
    base = Path(save_directory)
    base.mkdir(parents=True, exist_ok=True)

    folder = base / sanitize_path_segment(normalized["source"], "unknown")
    folder.mkdir(parents=True, exist_ok=True)

    file_name = f"{sanitize_path_segment(normalized['unique_key'])}.md"
    out_path = folder / file_name
    data = render_markdown(normalized)
    out_path.write_text(data, encoding="utf-8")
    return out_path, len(data.encode("utf-8")), normalized


def save_item_json(item: dict[str, Any], save_directory: str | Path):
    normalized = normalize_item(item)
    base = Path(save_directory)
    base.mkdir(parents=True, exist_ok=True)

    folder = base / sanitize_path_segment(normalized["source"], "unknown")
    folder.mkdir(parents=True, exist_ok=True)

    file_name = f"{sanitize_path_segment(normalized['unique_key'])}.json"
    out_path = folder / file_name
    data = json.dumps(normalized, indent=2, ensure_ascii=False)
    out_path.write_text(data, encoding="utf-8")
    return out_path, len(data.encode("utf-8")), normalized


def download_media(url: str, dest_dir: str | Path, filename_hint: str) -> Path | None:
    if not is_safe_url(url):
        return None

    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)

    suffix = Path(url.split("?", 1)[0]).suffix or ".bin"
    out_path = dest_dir / f"{sanitize_path_segment(filename_hint)}{suffix}"

    response = requests.get(url, timeout=30)
    response.raise_for_status()
    out_path.write_bytes(response.content)
    return out_path
