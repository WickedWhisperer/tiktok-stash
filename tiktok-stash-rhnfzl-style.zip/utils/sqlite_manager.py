from __future__ import annotations

import sqlite3
from pathlib import Path


def ensure_retry_db(db_path: str | Path) -> sqlite3.Connection:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS retry_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            unique_key TEXT NOT NULL,
            payload TEXT NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            next_attempt_at TEXT,
            status TEXT NOT NULL DEFAULT 'queued'
        )
        """
    )
    conn.commit()
    return conn


def ensure_index_db(db_path: str | Path) -> sqlite3.Connection:
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS archive_items (
            unique_key TEXT PRIMARY KEY,
            title TEXT,
            source TEXT,
            item_type TEXT,
            created_at TEXT,
            file_path TEXT,
            media_path TEXT,
            url TEXT,
            raw_json TEXT
        )
        """
    )
    conn.commit()
    return conn
