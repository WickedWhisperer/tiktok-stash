from __future__ import annotations

from pathlib import Path
from urllib.parse import urlparse
import re

_SAFE_CHARS = re.compile(r"[^A-Za-z0-9._-]+")


def is_safe_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
    except Exception:
        return False
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def safe_filename(name: str, fallback: str = "item") -> str:
    cleaned = _SAFE_CHARS.sub("_", name).strip("._-")
    return cleaned or fallback


def safe_subpath(value: str) -> Path:
    parts = [safe_filename(part) for part in value.replace("\\", "/").split("/") if part]
    return Path(*parts) if parts else Path("unknown")
